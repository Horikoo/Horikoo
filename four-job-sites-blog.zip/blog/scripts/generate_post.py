#!/usr/bin/env python3
"""
Generates one new blog post using the Claude API and wires it into the site.

Run manually:
    ANTHROPIC_API_KEY=sk-... python scripts/generate_post.py

Run automatically:
    via .github/workflows/auto-post.yml on a schedule (see that file).

What it does, step by step:
1. Picks the next category on a rotation (construction / tour / business / life)
   so the site stays balanced instead of drifting to one topic.
2. Asks Claude for a full post as JSON (title, slug, meta_description, body_html).
3. Writes posts/<slug>.html using the site's existing template + style.css.
4. Inserts a new card at the top of index.html's post grid.
5. Leaves everything staged for git to commit (the GitHub Action does the commit).
"""

import json
import os
import re
import sys
import urllib.request
from datetime import date, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
POSTS_DIR = ROOT / "posts"
INDEX_FILE = ROOT / "index.html"
STATE_FILE = ROOT / "scripts" / "state.json"

CATEGORIES = [
    {
        "key": "construction",
        "label": "Construction Safety",
        "brief": (
            "Construction site safety, OSHA compliance, skilled trades work, "
            "jobsite hazards, certifications, or practical safety habits. "
            "Written by someone who holds OSHA 10, OSHA 30, and CPR/AED certifications "
            "and works as a skilled worker in construction."
        ),
    },
    {
        "key": "tour",
        "label": "Tour Ops",
        "brief": (
            "Dolphin tour or boat tour operations: guest briefings, safety procedures, "
            "guest experience, snorkeling logistics, or running a small tourism operation. "
            "Written by someone who works in the dolphin tour industry."
        ),
    },
    {
        "key": "business",
        "label": "Business",
        "brief": (
            "Small business ownership, entrepreneurship, or lessons from running multiple "
            "businesses. Written by an MBA holder and former professional MMA fighter who has "
            "owned several businesses across different industries."
        ),
    },
    {
        "key": "life",
        "label": "Life & DIY",
        "brief": (
            "Practical DIY, home safety, or everyday-life topics viewed through a skilled "
            "tradesperson's eyes — the kind of practical judgment that comes from working "
            "in construction and running businesses."
        ),
    },
]

MODEL = "claude-sonnet-4-6"
API_URL = "https://api.anthropic.com/v1/messages"


def next_category():
    idx = 0
    if STATE_FILE.exists():
        try:
            idx = json.loads(STATE_FILE.read_text()).get("last_index", -1) + 1
        except Exception:
            idx = 0
    idx = idx % len(CATEGORIES)
    STATE_FILE.write_text(json.dumps({"last_index": idx}))
    return CATEGORIES[idx]


def slugify(title: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", title.lower()).strip("-")
    return slug[:60]


def call_claude(category: dict) -> dict:
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        sys.exit("ANTHROPIC_API_KEY environment variable is not set.")

    system_prompt = (
        "You write for 'Four Job Sites', a personal blog for a site that monetizes with "
        "Google AdSense. The voice is first-person, specific, and grounded in real experience "
        "— never generic listicle filler. Avoid clickbait phrasing. Target length: "
        "500-700 words of body content. Respond with ONLY valid JSON, no markdown fences, "
        "no preamble, matching exactly this shape:\n"
        '{"title": "...", "meta_description": "...(max 155 chars)", '
        '"body_html": "...(a sequence of <h2>, <p>, <ul><li> tags only, no <html> wrapper)"}'
    )
    user_prompt = (
        f"Write one blog post about: {category['brief']}\n\n"
        "Structure the body_html with 2-4 <h2> subheadings and concrete, specific advice "
        "or observations — not generic platitudes. Include at least one bulleted list. "
        "Do not repeat the exact topic of a certification comparison, a tour briefing checklist, "
        "an MMA-to-business post, or a home-safety checklist, since those already exist on the site."
    )

    payload = json.dumps({
        "model": MODEL,
        "max_tokens": 2000,
        "system": system_prompt,
        "messages": [{"role": "user", "content": user_prompt}],
    }).encode()

    req = urllib.request.Request(
        API_URL,
        data=payload,
        headers={
            "Content-Type": "application/json",
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
        },
    )
    with urllib.request.urlopen(req) as resp:
        data = json.loads(resp.read())

    text = "".join(block.get("text", "") for block in data.get("content", []))
    text = text.strip()
    text = re.sub(r"^```json|```$", "", text.strip(), flags=re.MULTILINE).strip()
    return json.loads(text)


POST_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title} | Four Job Sites</title>
<meta name="description" content="{meta_description}">
<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@500;600;700&family=Source+Serif+4:ital,wght@0,400;0,600;1,400&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../style.css">
</head>
<body>
<div class="post-wrap">
  <a class="back-link" href="../index.html">&larr; All posts</a>
  <span class="tag {category_key}">{category_label}</span>
  <h1>{title}</h1>
  <span class="post-date">{date_str}</span>

  <div class="post-body">
    {body_html}
  </div>
</div>
</body>
</html>
"""

CARD_TEMPLATE = """  <article class="post-card">
    <span class="tag {category_key}">{category_label}</span>
    <h2><a href="posts/{slug}.html">{title}</a></h2>
    <p>{meta_description}</p>
    <span class="post-meta">{date_short}</span>
  </article>
"""


def main():
    category = next_category()
    post = call_claude(category)

    title = post["title"].strip()
    meta_description = post["meta_description"].strip()
    body_html = post["body_html"].strip()
    slug = slugify(title)
    today = date.today()
    date_str = today.strftime("%B %-d, %Y") if os.name != "nt" else today.strftime("%B %d, %Y")
    date_short = today.strftime("%b %d %Y").upper()

    post_html = POST_TEMPLATE.format(
        title=title,
        meta_description=meta_description,
        category_key=category["key"],
        category_label=category["label"],
        date_str=date_str,
        body_html=body_html,
    )
    post_path = POSTS_DIR / f"{slug}.html"
    post_path.write_text(post_html, encoding="utf-8")
    print(f"Wrote {post_path}")

    card_html = CARD_TEMPLATE.format(
        category_key=category["key"],
        category_label=category["label"],
        slug=slug,
        title=title,
        meta_description=meta_description,
        date_short=date_short,
    )
    index_content = INDEX_FILE.read_text(encoding="utf-8")
    marker = "<!-- POSTS_START -->"
    if marker not in index_content:
        sys.exit("POSTS_START marker not found in index.html")
    index_content = index_content.replace(marker, marker + "\n" + card_html)
    INDEX_FILE.write_text(index_content, encoding="utf-8")
    print("Updated index.html")


if __name__ == "__main__":
    main()
