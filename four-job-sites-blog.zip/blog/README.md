# Four Job Sites — 자동화 블로그 설정 가이드

## 결론: KC님이 해야 할 일은 4가지뿐

1. GitHub 계정 만들기 + 이 폴더를 저장소(repo)로 올리기
2. GitHub Pages 켜기
3. Anthropic API 키를 발급받아 GitHub Secret에 등록하기
4. (선택) 도메인 연결 + AdSense 신청

이후부터는 매주 월요일 09:00(UTC)에 GitHub Actions가 자동으로 새 글을 쓰고 사이트에 올립니다.

---

## 1단계. GitHub에 올리기

1. https://github.com 에서 계정 생성 (무료)
2. 새 저장소(repository) 생성 — 이름 예: `four-job-sites`
3. 이 폴더 전체를 그 저장소에 업로드
   - 터미널을 쓸 줄 안다면:
     ```
     cd blog
     git init
     git remote add origin https://github.com/내아이디/four-job-sites.git
     git add .
     git commit -m "initial site"
     git branch -M main
     git push -u origin main
     ```
   - 터미널이 낯설면: GitHub 웹사이트에서 "Add file → Upload files" 로 폴더째 드래그 앤 드롭 가능

## 2단계. GitHub Pages 켜기

1. 저장소의 **Settings → Pages**로 이동
2. Source를 **Deploy from a branch** → `main` 브랜치, `/ (root)` 폴더로 설정
3. 저장 후 몇 분 지나면 `https://내아이디.github.io/four-job-sites/` 로 사이트가 열립니다

## 3단계. 완전자동화를 위한 API 키 등록

1. https://console.anthropic.com 에서 로그인 → **API Keys** 메뉴에서 새 키 생성
2. GitHub 저장소의 **Settings → Secrets and variables → Actions → New repository secret**
3. Name: `ANTHROPIC_API_KEY`, Value: 방금 발급받은 키 붙여넣기 → 저장

이걸로 끝입니다. `.github/workflows/auto-post.yml` 파일이 이미 들어있어서, 매주 월요일마다:
- 건설안전 → 투어운영 → 사업 → 생활/DIY 순서로 카테고리를 돌아가며
- Claude가 새 글을 쓰고
- 자동으로 사이트에 게시됩니다

**직접 지금 바로 테스트하고 싶다면:** 저장소의 **Actions** 탭 → `Auto-generate blog post` → **Run workflow** 버튼을 누르면 즉시 실행됩니다.

**주기를 바꾸고 싶다면:** `.github/workflows/auto-post.yml`의 `cron: "0 9 * * 1"` 부분을 수정하면 됩니다. (예: 매일 → `"0 9 * * *"`)

## 4단계. AdSense 신청 전 반드시 할 일

Google이 AdSense 승인에서 가장 많이 거절하는 이유 순서대로:

- [ ] **글이 최소 20~30개 쌓일 때까지 기다리기** — 지금은 예시 글 4개뿐입니다. 자동화를 2~3개월 돌리면서 채우세요.
- [ ] **`privacy-policy.html` 내용을 실제 정책으로 교체** — 지금은 플레이스홀더입니다. Google에서 "Privacy Policy Generator"를 검색해 무료 생성기로 만들어 붙여넣으세요.
- [ ] **`contact.html`에 실제 이메일 주소 입력**
- [ ] **커스텀 도메인 연결 권장** (`github.io` 서브도메인보다 자체 도메인이 승인에 유리합니다. Namecheap 등에서 연 1만원대)
- [ ] AdSense 승인 후 `index.html`의 `<!-- Google AdSense: paste your auto-ads script here once approved -->` 주석 자리에 발급받은 스크립트를 붙여넣기

## 파일 구조

```
blog/
├── index.html              ← 홈페이지 (자동으로 새 글 카드 추가됨)
├── style.css                ← 디자인
├── about.html / privacy-policy.html / contact.html
├── posts/                    ← 개별 글 (자동 생성됨)
├── scripts/
│   └── generate_post.py      ← Claude API 호출 + 글 생성 로직
└── .github/workflows/
    └── auto-post.yml         ← 자동 실행 스케줄
```

## 카테고리 직접 수정하고 싶다면

`scripts/generate_post.py` 상단의 `CATEGORIES` 리스트를 수정하면 주제를 바꾸거나 추가할 수 있습니다.
